Do NOT modify code in this module. It will get overwritten when doing a build
with files from the juddi-core module. Please modify code and tests in the juddi-core
module instead.

The reason we have this module is so that we can ship a juddi-core-openjpa jar with
pre-enhanced entities for running with OpenJPA.