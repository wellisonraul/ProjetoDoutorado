package ee.tkasekamp.ltlminer;

import java.util.Properties;

import org.deckfour.xes.model.XLog;
import org.junit.Test;

public class StarterTest {

	//@Test
	//public void test() throws Exception {
	//LTLMinerStarter starter = new LTLMinerStarter(getProps());
	//starter.mine();
	//}

	/*@Test
 public void test2() throws Exception {
  Properties props = getProps();
  props.setProperty("outputFormat", "text");
  props.setProperty("outputPath", "rules.txt");
  LTLMinerStarter starter = new LTLMinerStarter(props);
  starter.mine();
  assertTrue(new File("rules.txt").exists());
 }*/

	@Test
	public void test3() throws Exception {
		Properties props = getProps();
		//String queries = "\"[](( (?x{A,B})  ->  <>(?y{E,A})))\"; \"<>(?x{C,sad})\""; //original
		//String queries = "\"<>(?w{C,A})\"";
		//  props.setProperty("queries", queries); original
		//props.setProperty("considerEventTypes", "false");
		props.setProperty("minSupport", "0.0");
		LTLMinerStarter starter = new LTLMinerStarter(props);
		XLog a = null;
		//starter.mine(a);
		double saida;
		saida = starter.mine(a);
		System.out.println( "saida "+ saida);

	}

	private Properties getProps() {
		Properties props = new Properties();
		
		props.setProperty("logPath", "/Users/macbook/Google Drive/ProjetoDoutorado/eventlogmodificado.xes");
		props.setProperty("considerEventTypes", "true");
		props.setProperty("minSupport", "0.0");
		props.setProperty("outputFormat", "value");
		//props.setProperty("outputFormat", "console");
		//Caso queira salvar em um arquivo
		//props.setProperty("outputFormat", "text");
		//props.setProperty("outputPath", "rules.txt");

		
		String querieTeste1 = "\" <>(?act1{EscolhaProduto})\"";
		String queries3 = "\"(<>(((?res1{PagamentoDois:toSayValorDois}) /\\ (?act1{Pagamento}))))\"";
		String queries31 = "\"(<>(((?res1{Pagamento:toSayValor}) /\\ (?act1{Pagamento}))))\"";
		
		
		String queries = "\"[](( (?act1{B})  ->  <>(?act2{A})))\"";//\"<>(?x{C,sad})\"";

		//String queries3 = "\"([](( (?x{OrderGoods})  ->  <>(?y{ReceiveInvoice})))) /\\ (?y{OrderGoods})\""; 

		//String queries2 = "\"(?y{OrderGoods})  /\\ (?y{ReceiveInvoice})\"";
		//String queries4 = "\"[](( (?x{OrderGoods})  ->  <>(?y{ReceiveInvoice})))\"";
		String queries1 = "\" <>(?act1{ValorICMS})\"";
		//String queries1 =  "\" (<>(?x{Rayana}))\"";
		String queries2  = "\"(<>(?act1{ValorICMS})/\\ (?typ{completed}))\""; //(<>(activity == A))
		//(<>( resource==Rayana /\ activity==invited))
		//String queries3 = "\"(<>(((?res1{Pagamento:toSayValor}) /\\ (?act1{Pagamento}))))\"";
		//String queries3 = "\"(<>(((?res1{AliquotRate:toSayAliquot}) /\\ (?act1{ValorAliquota}))))\"";  //! ( <>(((activity == A) /\ _O(activity == A))) )
		String queries4 = "\" ((<>(?act1{ValorICMS}) <-> <>(?act2{ValorAliquota})))\"";//(<>(activity == A) <-> <>(activity == B)) 
		String queries5 = "\" (<>(?act1{A}) -> <> (?act2{E})) \"";//(<>(activity == A) -> <>(activity == B)) 
		String queries6 = "\"( [] (?x{A}) -> <>(?y{B})) \"";//[]( (activity == A -> <>(activity == B)) )				//( (activity != B _U activity == A) \/ [](activity != B) )
		String queries7 = "\" ((!(?x{D})_U(?y{C})) \\/ ([](!(?x{D}))) ) \"";//( (activity != B _U activity == A) \/ [](activity != B) )
		String queries8 = "\" []((((?x{A})  -> <> (?y{B})) /\\(( (!(?y{B}))_U(?x{A}))\\/ [](!(?y{B})))))\"";//[](( (activity == A -> <>(activity == B)) /\ ( (activity != B _U activity == A) \/ [](activity != B) ) ))
		String queries9 = "\" [] (((?x{B}) -> _O ( ( !(?x{A})_U (?y{D})))))\"";//[]( (activity == A -> _O( (activity != A _U activity == B) ) ) )
		//                     (( (activity != B _U activity == A) \/ [](activity != B) ) /\ []( (activity == B -> _O(( (activity != B _U activity == A) \/ [](activity != B) )))))
		String queries10 = "\"(( ( (!(?x{B}))_U (?y{A})) \\/ [](!(?x{B})) ) /\\ []( ((?x{B}) -> _O(( ((!(?x{B})) _U (?y{A})) \\/ [](!(?x{B}))  )))))  \""; 
		
		String queries11 = "\" (<>((?res1{ICMSRate:toSayFinalCost}) /\\ (?act1{ValorICMS}))\"";
		
		//((activity == A /\ eventype==complete) /\ (resource==Joao)) <-> activity == B
		
		String queries12 = "\" (((?act1{A}) /\\ (?res1{UNDEFINED})) <-> (?act2{B})) \"";
		
			
				//+ " /\\ _O(((?res1{Rayana})/\\ (?act2{invite})))))\"";
				//<>(((person==x /\\ activity ==y) /\\_O(person==x /\\ activity==z))))
		
		props.setProperty("queries", queries31);

		return props;
	}

}