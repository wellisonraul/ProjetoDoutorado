LTLMiner
=============

Application developed for discovering declerative process models.

This is a tool for process mining that uses a version of LTLChecker found [here](https://bitbucket.org/TKasekamp/ltlchecker-alone).

Performance tests can be found [here](https://github.com/TKasekamp/ltlminer-tests).
